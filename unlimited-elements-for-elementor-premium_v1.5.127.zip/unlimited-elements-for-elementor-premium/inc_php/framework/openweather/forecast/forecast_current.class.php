<?php

class UEOpenWeatherAPIForecastCurrent extends UEOpenWeatherAPIForecastAbstract{

	use UEOpenWeatherAPIForecastHasInlineTemperature, UEOpenWeatherAPIForecastHasSunTime;

}
