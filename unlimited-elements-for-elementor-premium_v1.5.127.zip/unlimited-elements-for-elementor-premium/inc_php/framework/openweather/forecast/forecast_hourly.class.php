<?php

class UEOpenWeatherAPIForecastHourly extends UEOpenWeatherAPIForecastAbstract{

	use UEOpenWeatherAPIForecastHasInlineTemperature;

}
