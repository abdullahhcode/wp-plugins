<div class="ffp_submission_header">
    <div class="ffp_submission_message">
        <?php echo $header_content; ?>
    </div>
</div>