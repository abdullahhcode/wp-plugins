<div class="ff_inventory_list" id="ff_inventory_list_app">
    <ff-inventory-list :form_id="<?php echo $form_id; ?>"/>
</div>
